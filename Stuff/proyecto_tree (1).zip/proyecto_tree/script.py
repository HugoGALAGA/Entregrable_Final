
import sys
import os
from Tree import Node, Tree # Importamos las clases desde el archivo Tree.py

def build_directory_tree(path: str) -> Tree:
    '''
    Scans the given path and builds a tree structure using the Tree and Node classes.
    Assumes the path is a directory.
    '''
    # Get the name of the current directory/file for the node
    # Use the full path if it's the root path (e.g., '.', '/') for clarity,
    # otherwise just the base name.
    node_name = os.path.basename(path) or path # Handles root path cases

    # Create the root Tree node for the current directory being processed
    current_tree_node = Tree(node_name)

    # Use a dictionary to map directory paths to their corresponding Tree nodes
    # This helps in the os.walk approach to link children to their parent nodes
    # We need this dictionary to build the tree when using os.walk
    # The root node is the first one we create
    # Note: Using os.walk is generally more efficient for full traversal
    # than manual recursion with os.listdir for large trees.

    # Let's use a recursive approach for simplicity, mapping more directly
    # to the Tree/Node insert_child structure.
    # A dictionary is needed if using os.walk to link parent nodes easily.
    # Let's refactor to use os.walk with a dictionary mapping.

    # --- Refactored approach using os.walk and dictionary ---
    tree_nodes = {}

    # The very root node of the scan
    root_node_name = os.path.basename(path) or path
    root_tree_node = Tree(root_node_name)
    tree_nodes[os.path.abspath(path)] = root_tree_node # Map the absolute path to the root node

    print(f"Escaneando: {path} ...")

    # Walk through the directory tree starting from the given path
    # We handle errors during the walk
    try:
        # topdown=True is the default, which is fine.
        # followlinks=False is default, good to avoid infinite loops with symlinks.
        for dirpath, dirnames, filenames in os.walk(path):
            # Get the Tree node corresponding to the current directory (dirpath)
            # This node should already exist in our dictionary, created by the parent level
            # or it's the root node itself.
            # Need to use absolute path for dictionary keys to be consistent.
            current_node_key = os.path.abspath(dirpath)

            if current_node_key not in tree_nodes:
                 # This case should ideally not happen if os.walk behaves as expected
                 # and the root path is added initially.
                 # However, if os.walk yields a directory we couldn't access before,
                 # or due to complex symlinks/mount points not followed, this might occur.
                 # For robustness, we could skip or create a placeholder node.
                 print(f"Advertencia: Nodo padre no encontrado en el diccionario para {dirpath}")
                 continue # Skip processing children for this directory

            current_tree_node = tree_nodes[current_node_key]

            # Add subdirectories (Tree objects)
            for dirname in dirnames:
                subdir_path = os.path.join(dirpath, dirname)
                subdir_node_name = dirname # Just the name for the node
                subdir_tree_node = Tree(subdir_node_name)

                # Add the new subdirectory node to the dictionary
                # This allows its children (in a later walk iteration) to find it
                tree_nodes[os.path.abspath(subdir_path)] = subdir_tree_node

                # Insert the subdirectory node as a child of the current directory node
                current_tree_node.insert_child(subdir_tree_node)

            # Add files (Node objects)
            for filename in filenames:
                file_node = Node(filename)
                # Insert the file node as a child of the current directory node
                current_tree_node.insert_child(file_node)

    except PermissionError:
        print(f"Error: Permiso denegado para acceder a {path}")
        # In case of PermissionError at the very root, the tree will be empty except for the root node.
        # If it happens in a subdir, os.walk might just skip it, or raise error if onerror is not None.
        # With the default os.walk, it might just skip the directory and print an error to stderr.
        # The try-except here captures errors related to the initial path or unhandled ones by os.walk.
        return root_tree_node # Return what we could build

    except Exception as e:
        print(f"Ocurrió un error inesperado al escanear {path}: {e}")
        return root_tree_node # Return what we could build

    print("Escaneo completado.")
    # The root_tree_node now holds the entire structure
    return root_tree_node


def print_directory_tree(node: any, indent: str = "", is_last: bool = True):
    '''
    Prints the directory tree structure visually to the console.
    Uses indentation and lines to show hierarchy.
    node: The current Node or Tree object to print.
    indent: The current indentation string from parent levels.
    is_last: True if this node is the last child of its parent.
    '''
    # Choose the connector based on whether it's the last child
    connector = "└── " if is_last else "├── "

    # Print the current node with indentation and connector
    print(f"{indent}{connector}{node.name}")

    # If it's a Tree node (directory), print its children
    if isinstance(node, Tree):
        children = node.get_children()
        num_children = len(children)

        # Determine the indentation for the children
        # If the current node was the last child of its parent, its children
        # will not need a vertical line extending down from where the node was.
        # Otherwise, they will need the vertical line.
        next_indent = indent + ("    " if is_last else "│   ") # 4 spaces or line + 3 spaces

        # Recursively print children
        for i, child in enumerate(children):
            # Check if the child is the last one in the list
            child_is_last = (i == num_children - 1)
            print_directory_tree(child, next_indent, child_is_last)


# --- Main execution block ---
if __name__ == "__main__":
    # Instruction 1: Reciba como parámetro un path del sistema de archivos
    if len(sys.argv) < 2:
        print("Uso: python directory_tree_scanner.py <ruta_a_escanear>")
        sys.exit(1) # Exit if no path is provided

    scan_path = sys.argv[1]

    # Basic validation
    if not os.path.exists(scan_path):
        print(f"Error: La ruta '{scan_path}' no existe.")
        sys.exit(1)

    if not os.path.isdir(scan_path):
        print(f"Error: La ruta '{scan_path}' no es un directorio.")
        sys.exit(1)

    # Instruction 2 & 3: Scan and represent using Tree/Node structure
    # The build_directory_tree function does this
    root_tree = build_directory_tree(scan_path)

    # Instruction 4: Imprimir el árbol en consola de alguna forma visual
    # The print_directory_tree function does this
    print("\n--- Estructura del Directorio ---")

    # Special case: print the root node first without connector lines extending above it
    print(root_tree.name)
    # Then print its children with the correct initial indentation and connectors
    root_children = root_tree.get_children()
    num_root_children = len(root_children)
    for i, child in enumerate(root_children):
         # For the root's children, the 'indent' starts empty, but the 'is_last' logic applies
         # The first level children use either ├── or └── with an empty preceding indent.
         # The recursive calls handle the subsequent indentations.
         print_directory_tree(child, "", i == num_root_children - 1)

    print("--- Fin de la Estructura ---")