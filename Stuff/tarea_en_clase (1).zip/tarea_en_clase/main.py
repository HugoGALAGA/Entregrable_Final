# Ejemplo usando Click con múltiples comandos en un grupo

import click
from datetime import datetime 

@click.group()
def cli():
    """Un grupo de comandos de ejemplo."""
    pass 

#Hello
@cli.command()
@click.option("--count", default=1, help="Number of greetings.")
@click.option("--name", prompt="Your name", help="The person to greet.")
def hello(count, name):
    """Simple program that greets NAME for a total of COUNT times."""
    for _ in range(count):
        click.echo(f"Hello, {name}!")

#Timenow
@cli.command()
def timenow():
    """Imprime la fecha y hora actual."""
    print(f'{datetime.now()}') 



#greet
@cli.command()
@click.argument('name') 
@click.option('--loud', is_flag=True, default=False, help='Greet loudly.') 
def greet(name, loud):
    """Saluda a una persona por su nombre (con argumento)."""
    greeting = f"Hola, {name}!"
    if loud:
        greeting = greeting.upper() 
    click.echo(greeting)


#repeat
@cli.command()
@click.option('--text', required=True, help='The text to repeat.') 
@click.option('--times', type=int, default=1, help='Number of times to repeat.') 
def repeat(text, times):
    """Repite un texto un numero de veces."""
    if times <= 0:
        click.echo("El número de repeticiones debe ser positivo.", err=True) 
        return # Salir de la función
    for _ in range(times):
        click.echo(text)


# --- Fin de NUEVOS COMANDOS ---


if __name__ == '__main__':
    # Al llamar a cli(), Click toma el control y dirige la ejecución
    # al subcomando especificado por el usuario (hello, timenow, greet, o repeat)
    cli()