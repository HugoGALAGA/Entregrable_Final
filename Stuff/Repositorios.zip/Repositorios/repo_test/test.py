print ("Hello")
