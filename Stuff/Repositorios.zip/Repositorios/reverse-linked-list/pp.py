import json
import matplotlib.pyplot as plt
import numpy as np
from datetime import datetime
import tkinter as tk
from tkinter import ttk

# Cargar los datos del archivo JSON
file_path = r"D:\Descargas\weatherstation-23ec0-default-rtdb-Brazos_al_pastor-export.json"

with open(file_path, "r", encoding="utf-8") as file:
    data = json.load(file)

# Inicializar listas para almacenar datos
timestamps = []
temperaturas = []
humedades = []
presiones = []
vientos = []

# Extraer los datos relevantes
for timestamp, values in data.items():
    if isinstance(values, dict):
        for _, entry in values.items():
            try:
                timestamps.append(datetime.strptime(timestamp, "%Y-%m-%d_%H:%M:%S"))
                temperaturas.append(entry.get("temperatura", 0))
                humedades.append(entry.get("humedad", 0))
                presiones.append(entry.get("presion", 0))
                vientos.append(entry.get("velocidad_viento", 0))
            except Exception as e:
                print(f"Error procesando el dato {timestamp}: {e}")

# Filtrar datos atípicos usando el rango intercuartílico (IQR)
def remove_outliers(data):
    q1, q3 = np.percentile(data, [25, 75])
    iqr = q3 - q1
    lower_bound = q1 - 1.5 * iqr
    upper_bound = q3 + 1.5 * iqr
    return [x for x in data if lower_bound <= x <= upper_bound]

temperaturas = remove_outliers(temperaturas)
humedades = remove_outliers(humedades)
presiones = remove_outliers(presiones)
vientos = remove_outliers(vientos)

# Calcular estadísticas
stats = {
    "Temperatura (°C)": (np.mean(temperaturas), np.std(temperaturas)),
    "Humedad (%)": (np.mean(humedades), np.std(humedades)),
    "Presión (hPa)": (np.mean(presiones), np.std(presiones)),
    "Vel. Viento (km/h)": (np.mean(vientos), np.std(vientos)),
}

# Crear ventana con tabla de estadísticas
root = tk.Tk()
root.title("Estadísticas del Clima")

frame = ttk.Frame(root, padding=10)
frame.grid(row=0, column=0)

# Crear tabla
columns = ("Parámetro", "Media", "Desviación Est.")
tree = ttk.Treeview(frame, columns=columns, show="headings", height=5)

for col in columns:
    tree.heading(col, text=col)
    tree.column(col, anchor="center")

# Insertar datos en la tabla
for key, (mean, std) in stats.items():
    tree.insert("", "end", values=(key, f"{mean:.2f}", f"{std:.2f}"))

# Aplicar estilos visuales
style = ttk.Style()
style.configure("Treeview.Heading", font=("Arial", 12, "bold"), foreground="black", background="lightblue")
style.configure("Treeview", font=("Arial", 10))

tree.grid(row=0, column=0)
root.mainloop()

# Graficar los datos
fig, ax1 = plt.subplots(figsize=(12, 6))
ax1.set_xlabel("Tiempo")
ax1.set_ylabel("Temperatura (°C)", color="red")
ax1.plot(timestamps[:len(temperaturas)], temperaturas, "r-", label="Temperatura")
ax1.tick_params(axis='y', labelcolor="red")

ax2 = ax1.twinx()
ax2.set_ylabel("Humedad (%)", color="blue")
ax2.plot(timestamps[:len(humedades)], humedades, "b-", label="Humedad")
ax2.tick_params(axis='y', labelcolor="blue")

fig.tight_layout()
plt.title("Temperatura y Humedad a lo largo del tiempo")
plt.show()

# Segunda gráfica: Presión y velocidad del viento
fig, ax3 = plt.subplots(figsize=(12, 6))
ax3.set_xlabel("Tiempo")
ax3.set_ylabel("Presión (hPa)", color="green")
ax3.plot(timestamps[:len(presiones)], presiones, "g-", label="Presión")
ax3.tick_params(axis='y', labelcolor="green")

ax4 = ax3.twinx()
ax4.set_ylabel("Velocidad del viento (km/h)", color="purple")
ax4.plot(timestamps[:len(vientos)], vientos, "purple", label="Vel. Viento")
ax4.tick_params(axis='y', labelcolor="purple")

fig.tight_layout()
plt.title("Presión y Velocidad del viento a lo largo del tiempo")
plt.show()