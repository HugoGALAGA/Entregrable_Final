import json
import matplotlib.pyplot as plt
import numpy as np
from datetime import datetime

# Cargar los datos del archivo JSON
file_path = r"D:\Descargas\weatherstation-23ec0-default-rtdb-Brazos_al_pastor-export.json"

with open(file_path, "r", encoding="utf-8") as file:
    data = json.load(file)

# Inicializar listas para almacenar datos
timestamps = []
temperaturas = []
humedades = []
altitudes = []
niveles_luz = []
presiones = []
vientos = []

# Extraer los datos relevantes
for timestamp, values in data.items():
    if isinstance(values, dict):
        for _, entry in values.items():
            try:
                timestamps.append(datetime.strptime(timestamp, "%Y-%m-%d_%H:%M:%S"))
                temperaturas.append(entry.get("temperatura", 0))
                humedades.append(entry.get("humedad", 0))
                altitudes.append(entry.get("altitud", 0))
                niveles_luz.append(entry.get("nivel_luz", 0))
                presiones.append(entry.get("presion", 0))
                vientos.append(entry.get("velocidad_viento", 0))
            except Exception as e:
                print(f"Error procesando el dato {timestamp}: {e}")

# Filtrar datos atípicos usando el rango intercuartílico (IQR)
def remove_outliers(data):
    if len(data) < 4:
        return data  # Evita errores si hay pocos datos
    q1, q3 = np.percentile(data, [25, 75])
    iqr = q3 - q1
    lower_bound = q1 - 1.5 * iqr
    upper_bound = q3 + 1.5 * iqr
    return [x for x in data if lower_bound <= x <= upper_bound]

variables = {
    "Temperatura (°C)": temperaturas,
    "Humedad (%)": humedades,
    "Altitud (m)": altitudes,
    "Nivel de Luz": niveles_luz,
    "Presión (hPa)": presiones,
    "Vel. Viento (km/h)": vientos
}

for key in variables:
    variables[key] = remove_outliers(variables[key])

# Crear las gráficas
fig, axs = plt.subplots(2, 3, figsize=(12, 8))
fig.suptitle("Datos de la Estación Meteorológica", fontsize=16, fontweight="bold")

i = 0
for key, values in variables.items():
    row, col = divmod(i, 3)
    axs[row, col].plot(values, marker="o", linestyle="-", label=key)
    axs[row, col].set_title(key, fontsize=12, fontweight="bold")
    axs[row, col].set_xlabel("Tiempo")
    axs[row, col].set_ylabel(key)
    axs[row, col].grid()
    axs[row, col].legend()
    i += 1

plt.tight_layout(rect=[0, 0, 1, 0.96])
plt.show()
