import json
import matplotlib.pyplot as plt
from datetime import datetime

# Cargar los datos del archivo JSON
file_path = r"D:\Descargas\weatherstation-23ec0-default-rtdb-Brazos_al_pastor-export.json"

with open(file_path, "r", encoding="utf-8") as file:
    data = json.load(file)

# Inicializar listas para almacenar datos
timestamps = []
temperaturas = []
humedades = []
presiones = []
vientos = []

# Extraer los datos relevantes
for timestamp, values in data.items():
    if isinstance(values, dict):
        for _, entry in values.items():
            try:
                timestamps.append(datetime.strptime(timestamp, "%Y-%m-%d_%H:%M:%S"))
                temperaturas.append(entry.get("temperatura", 0))
                humedades.append(entry.get("humedad", 0))
                presiones.append(entry.get("presion", 0))
                vientos.append(entry.get("velocidad_viento", 0))
            except Exception as e:
                print(f"Error procesando el dato {timestamp}: {e}")

# Ordenar los datos por tiempo
sorted_indices = sorted(range(len(timestamps)), key=lambda i: timestamps[i])
timestamps = [timestamps[i] for i in sorted_indices]
temperaturas = [temperaturas[i] for i in sorted_indices]
humedades = [humedades[i] for i in sorted_indices]
presiones = [presiones[i] for i in sorted_indices]
vientos = [vientos[i] for i in sorted_indices]

# Graficar los datos
fig, ax1 = plt.subplots(figsize=(12, 6))
ax1.set_xlabel("Tiempo")
ax1.set_ylabel("Temperatura (°C)", color="red")
ax1.plot(timestamps, temperaturas, "r-", label="Temperatura")
ax1.tick_params(axis='y', labelcolor="red")

ax2 = ax1.twinx()
ax2.set_ylabel("Humedad (%)", color="blue")
ax2.plot(timestamps, humedades, "b-", label="Humedad")
ax2.tick_params(axis='y', labelcolor="blue")

fig.tight_layout()
plt.title("Temperatura y Humedad a lo largo del tiempo")
plt.show()

# Segunda gráfica: Presión y velocidad del viento
fig, ax3 = plt.subplots(figsize=(12, 6))
ax3.set_xlabel("Tiempo")
ax3.set_ylabel("Presión (hPa)", color="green")
ax3.plot(timestamps, presiones, "g-", label="Presión")
ax3.tick_params(axis='y', labelcolor="green")

ax4 = ax3.twinx()
ax4.set_ylabel("Velocidad del viento (km/h)", color="purple")
ax4.plot(timestamps, vientos, "purple", label="Vel. Viento")
ax4.tick_params(axis='y', labelcolor="purple")

fig.tight_layout()
plt.title("Presión y Velocidad del viento a lo largo del tiempo")
plt.show()
