#3. Impacto de yield en el consumo de memoria
#Ejercicio: Crea una función que genere el primero 1 millone de números cuadrados de dos formas:

#Usando una lista (return [x**2 for x in range(n)]).
#Usando un generador (yield x**2).
#Usa memory-profiler para medir la diferencia en consumo de memoria entre ambas implementaciones.

#Objetivo: Ver cómo los generadores pueden optimizar el uso de memoria.

from memory_profiler import profile

def square_list(n):
    """Genera los primeros n números cuadrados usando una lista."""
    return [x**2 for x in range(n)]

def square_generator(n):
    """Genera los primeros n números cuadrados usando un generador."""
    for x in range(n):
        yield x**2

@profile
def test_list(n):
    squares = square_list(n)
    return squares

@profile
def test_generator(n):
    squares = square_generator(n)
    for _ in squares:
        pass  # Consumimos el generador sin almacenarlo en memoria

if __name__ == "__main__":
    n = 100_000  # Reducimos a 100 mil elementos para evitar consumo excesivo de memoria
    # test_list(n)  # Comentamos esta línea para ejecutar solo el generador
    test_generator(n)
