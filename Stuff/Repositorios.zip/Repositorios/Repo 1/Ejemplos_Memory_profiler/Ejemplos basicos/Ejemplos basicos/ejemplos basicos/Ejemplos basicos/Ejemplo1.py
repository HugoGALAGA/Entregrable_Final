#Comparar estructuras de datos en Python
#Crea un programa que almacene 1 millón de números enteros usando diferentes estructuras de 
#datos (list, set, dict, numpy.array). Usa memory-profiler para determinar cuál consume menos memoria.

#bjetivo: Evaluar el impacto del tipo de estructura en el consumo de memoria.


from memory_profiler import profile
import numpy as np

@profile
def compare_memory():
    n = 10**6  # 1 millón de elementos
    
    # Lista de enteros
    list_data = list(range(n))
    
    # Conjunto de enteros
    set_data = set(range(n))
    
    # Diccionario con claves y valores iguales
    dict_data = {i: i for i in range(n)}
    
    # Array de NumPy
    numpy_data = np.arange(n, dtype=np.int32)
    
    return list_data, set_data, dict_data, numpy_data

if __name__ == "__main__":
    compare_memory()
