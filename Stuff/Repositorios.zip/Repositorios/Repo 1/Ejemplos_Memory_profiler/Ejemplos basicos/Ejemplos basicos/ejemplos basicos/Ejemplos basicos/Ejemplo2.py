#Análisis de funciones recursivas vs iterativas
#Ejercicio: Implementa el cálculo de Fibonacci de dos formas:
#Recursiva
#Iterativa
#Usa memory-profiler para medir cuál de las dos versiones consume más memoria y analiza por qué.

#Objetivo: Comparar el impacto de la recursión en el uso de memoria.

from memory_profiler import profile
import numpy as np

@profile
def compare_memory():
    n = 10**6  # 1 millón de elementos
    
    # Lista de enteros
    list_data = list(range(n))
    
    # Conjunto de enteros
    set_data = set(range(n))
    
    # Diccionario con claves y valores iguales
    dict_data = {i: i for i in range(n)}
    
    # Array de NumPy
    numpy_data = np.arange(n, dtype=np.int32)
    
    return list_data, set_data, dict_data, numpy_data

@profile
def fibonacci_recursive_single():
    return fibonacci_recursive(10)

def fibonacci_recursive(n):
    if n <= 1:
        return n
    return fibonacci_recursive(n - 1) + fibonacci_recursive(n - 2)

@profile
def fibonacci_iterative_single():
    return fibonacci_iterative(10)

def fibonacci_iterative(n):
    a, b = 0, 1
    for _ in range(n):
        a, b = b, a + b
    return a

if __name__ == "__main__":
    compare_memory()
    fibonacci_recursive_single()
    fibonacci_iterative_single()
