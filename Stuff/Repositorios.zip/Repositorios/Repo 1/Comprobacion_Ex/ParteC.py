import time
import string

class Stack:
    def __init__(self, capacity):
        self.capacity = capacity
        self.stack = []

    def is_full(self):
        return len(self.stack) >= self.capacity

    def push(self, item):
        if not self.is_full():
            self.stack.append(item)

    def search(self, key):
        try:
            return self.stack.index(key)
        except ValueError:
            return -1

# 📌 Función para obtener letras en orden secuencial
def get_letter(index):
    letters = string.ascii_uppercase  # 'A' to 'Z'
    return letters[index % len(letters)]

# 📌 Función para medir el tiempo de llenado y búsqueda
def measure_times(n):
    stack = Stack(n)

    # 🔹 Medir tiempo de llenado
    start_fill = time.perf_counter()
    for i in range(n):
        stack.push(get_letter(i))
    end_fill = time.perf_counter()
    fill_time = end_fill - start_fill

    # 🔹 Medir tiempo de búsqueda del último elemento
    search_key = stack.stack[-1]  # Última letra insertada
    start_search = time.perf_counter()
    position = stack.search(search_key)
    end_search = time.perf_counter()
    search_time = end_search - start_search

    return fill_time, search_time

# 📌 Medir y mostrar tiempos para n, 2n, 3n, 4n, 5n
n = 2400000  # Tamaño base de la pila

for multiplier in range(1, 6):
    size = n * multiplier
    fill_time, search_time = measure_times(size)
    print(f"Tamaño: {size}")
    print(f"  Tiempo de llenado: {fill_time:.6f} segundos")
    print(f"  Tiempo de búsqueda del último elemento: {search_time:.6f} segundos")
    print("-" * 50)
