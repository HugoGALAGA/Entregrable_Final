import time
import string

class Stack:
    def __init__(self, capacity):
        self.capacity = capacity
        self.stack = []

    def is_full(self):
        return len(self.stack) >= self.capacity

    def push(self, item):
        if not self.is_full():
            self.stack.append(item)

    def search(self, key):
        try:
            return self.stack.index(key)
        except ValueError:
            return -1

    def pop(self):
        if len(self.stack) > 0:
            return self.stack.pop()
        return None

# 📌 Función para obtener letras en orden secuencial
def get_letter(index):
    letters = string.ascii_uppercase  # 'A' to 'Z'
    return letters[index % len(letters)]

# 📌 Función para medir el tiempo de búsqueda de un elemento inexistente
def measure_search_times(n):
    stack = Stack(n)

    # 🔹 Llenar la pila
    for i in range(n):
        stack.push(get_letter(i))

    # 🔹 Medir tiempo de búsqueda de un elemento inexistente
    search_key = "7"  # Elemento que no existe en la pila
    start_search = time.perf_counter()
    position = stack.search(search_key)
    end_search = time.perf_counter()
    search_time = end_search - start_search

    return search_time

# 📌 Función para medir el tiempo de la operación pop (eliminar el último elemento)
def measure_pop_times(n):
    stack = Stack(n)

    # 🔹 Llenar la pila
    for i in range(n):
        stack.push(get_letter(i))

    # 🔹 Medir tiempo de operación pop (eliminar el último elemento)
    start_pop = time.perf_counter()
    popped_item = stack.pop()
    end_pop = time.perf_counter()
    pop_time = end_pop - start_pop

    return pop_time

# 📌 Menú de opciones
def menu():
    print("Seleccione una opción:")
    print("a) Medir tiempo de búsqueda de un elemento inexistente")
    print("b) Medir tiempo de operación pop (eliminar el último elemento)")
    option = input("Ingrese 'a' o 'b': ").strip().lower()
    
    return option

# 📌 Medir y mostrar tiempos para n, 2n, 3n, 4n, 5n
n = 2400000  # Tamaño base de la pila

# Selección de opción
option = menu()

if option == 'a':  # Opción A: Búsqueda de un elemento inexistente
    for multiplier in range(1, 6):
        size = n * multiplier
        search_time = measure_search_times(size)
        print(f"Tamaño: {size}")
        print(f"  Tiempo de búsqueda de un elemento inexistente: {search_time:.6f} segundos")
        print("-" * 50)

elif option == 'b':  # Opción B: Operación pop (eliminar el último elemento)
    for multiplier in range(1, 6):
        size = n * multiplier
        pop_time = measure_pop_times(size)
        print(f"Tamaño: {size}")
        print(f"  Tiempo de operación pop: {pop_time:.6f} segundos")
        print("-" * 50)

else:
    print("Opción no válida. Por favor, ingrese 'a' o 'b'.")
