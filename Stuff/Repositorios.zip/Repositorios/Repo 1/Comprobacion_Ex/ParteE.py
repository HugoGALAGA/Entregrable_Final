import matplotlib.pyplot as plt

# 📌 Datos obtenidos en el ejercicio 5
tamanos = [2400000, 4800000, 7200000, 9600000, 12000000]
tiempo_search = [0.026574, 0.067615, 0.106375, 0.115743, 0.143995]
tiempo_pop = [0.000004, 0.000004, 0.000001, 0.000002, 0.000001]

# 📌 Crear la gráfica
plt.figure(figsize=(8, 6))
plt.plot(tamanos, tiempo_search, marker='o', linestyle='-', color='b', label='Tiempo de búsqueda (search)')
plt.plot(tamanos, tiempo_pop, marker='s', linestyle='--', color='r', label='Tiempo de eliminación (pop)')

# 📌 Configurar la gráfica
plt.xlabel('Tamaño de la estructura')
plt.ylabel('Tiempo (segundos)')
plt.title('Comparación de tiempos: search() vs pop()')
plt.legend()
plt.grid(True)

# 📌 Guardar y mostrar
plt.savefig('grafica_tiempos.png')
plt.show()
