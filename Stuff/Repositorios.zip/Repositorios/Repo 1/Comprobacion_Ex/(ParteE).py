import time
import string
import cProfile
import pstats
import sys
import matplotlib.pyplot as plt

class Stack:
    def __init__(self, capacity):
        self.capacity = capacity
        self.stack = []

    def is_full(self):
        return len(self.stack) >= self.capacity

    def push(self, item):
        if not self.is_full():
            self.stack.append(item)

    def search(self, key):
        try:
            return self.stack.index(key)
        except ValueError:
            return -1

    def pop(self):
        if self.stack:
            return self.stack.pop()

# 📌 Función para obtener letras en orden secuencial
def get_letter(index):
    letters = string.ascii_uppercase  # 'A' to 'Z'
    return letters[index % len(letters)]

# 📌 Función para llenar la pila
def fill_stack(n):
    stack = Stack(n)
    for i in range(n):
        stack.push(get_letter(i))
    return stack

# 📌 Función para perfilar la búsqueda de un elemento inexistente
def profile_search(stack, search_key):
    pr = cProfile.Profile()
    pr.enable()
    stack.search(search_key)
    pr.disable()
    return pr

# 📌 Función para perfilar la operación pop
def profile_pop(stack):
    pr = cProfile.Profile()
    pr.enable()
    stack.pop()
    pr.disable()
    return pr

# 📌 Función para ejecutar la opción A
def execute_option_a(n):
    stack = fill_stack(n)
    search_key = '7'  # Un valor que no está en la pila

    start_time = time.perf_counter()
    stack.search(search_key)
    end_time = time.perf_counter()
    search_time = end_time - start_time

    pr = profile_search(stack, search_key)

    print(f"Tamaño: {n}")
    print(f"  Tiempo de búsqueda de un elemento inexistente: {search_time:.6f} segundos")
    print("-" * 50)

    stats = pstats.Stats(pr, stream=sys.stdout)
    stats.strip_dirs().sort_stats("time").print_stats(10)
    return search_time

# 📌 Función para ejecutar la opción B
def execute_option_b(n):
    stack = fill_stack(n)

    start_time = time.perf_counter()
    stack.pop()
    end_time = time.perf_counter()
    pop_time = end_time - start_time

    pr = profile_pop(stack)

    print(f"Tamaño: {n}")
    print(f"  Tiempo de operación pop: {pop_time:.6f} segundos")
    print("-" * 50)

    stats = pstats.Stats(pr, stream=sys.stdout)
    stats.strip_dirs().sort_stats("time").print_stats(10)
    return pop_time

# 📌 Función para generar y guardar la gráfica
def generate_graph(sizes, search_times, pop_times):
    plt.figure(figsize=(10, 5))
    plt.plot(sizes, search_times, marker='o', linestyle='-', color='b', label="Tiempo de búsqueda")
    plt.plot(sizes, pop_times, marker='s', linestyle='--', color='r', label="Tiempo de eliminación (pop)")
    plt.xlabel("Tamaño de la estructura (n)")
    plt.ylabel("Tiempo (segundos)")
    plt.title("Comparación de Tiempos: Search vs. Pop")
    plt.legend()
    plt.grid(True)
    plt.savefig("grafica_tiempos.png", dpi=300)
    plt.show()

# 📌 Menú interactivo
def main():
    n = 2400000  # Tamaño base
    opciones = [n * i for i in range(1, 6)]
    search_times = []
    pop_times = []

    while True:
        print("\nSeleccione una opción:")
        print("A - Buscar un elemento inexistente")
        print("B - Realizar operación pop")
        print("X - Salir")
        choice = input("Ingrese su elección: ").strip().upper()

        if choice == "X":
            print("Generando gráfica...")
            generate_graph(opciones, search_times, pop_times)
            print("Saliendo del programa...")
            break

        if choice not in ["A", "B"]:
            print("Opción inválida, intente nuevamente.")
            continue

        print("\nSeleccione el tamaño:")
        for i, size in enumerate(opciones, 1):
            print(f"{i} - {size}")

        try:
            size_choice = int(input("Ingrese el número de la opción: "))
            if size_choice < 1 or size_choice > 5:
                raise ValueError
        except ValueError:
            print("Opción inválida, intente nuevamente.")
            continue

        selected_size = opciones[size_choice - 1]

        if choice == "A":
            search_times.append(execute_option_a(selected_size))
        elif choice == "B":
            pop_times.append(execute_option_b(selected_size))

# 📌 Ejecutar el menú
if __name__ == "__main__":
    main()
