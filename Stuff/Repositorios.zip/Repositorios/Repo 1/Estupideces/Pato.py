import pygame
import os
from PIL import Image, ImageSequence

# Inicializar pygame
pygame.init()

# Configuración de la ventana
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("El pato sigue el cursor")

# Cargar el GIF y extraer los cuadros correctamente
gif_path = "patpato.gif"  # Asegúrate de que el archivo está en la misma carpeta
gif = Image.open(gif_path)

frames = []
for frame in ImageSequence.Iterator(gif):
    frame = frame.convert("RGBA")  # Convertir a formato compatible con pygame
    frame_surface = pygame.image.fromstring(frame.tobytes(), frame.size, "RGBA")
    frame_surface = pygame.transform.scale(frame_surface, (80, 80))  # Ajusta el tamaño del pato
    frames.append(frame_surface)

# Posición inicial del pato
duck_x, duck_y = WIDTH // 2, HEIGHT // 2
speed = 2  # Velocidad de movimiento
frame_index = 0  # Índice del cuadro actual

# Bucle principal
running = True
while running:
    screen.fill((135, 206, 250))  # Fondo azul cielo
    
    # Obtener posición del cursor
    mouse_x, mouse_y = pygame.mouse.get_pos()
    
    # Calcular dirección de movimiento
    dx, dy = mouse_x - duck_x, mouse_y - duck_y
    distance = max(abs(dx), abs(dy))
    
    if distance > 0:
        duck_x += (dx / distance) * speed
        duck_y += (dy / distance) * speed
    
    # Dibujar el pato animado
    screen.blit(frames[frame_index], (duck_x, duck_y))
    frame_index = (frame_index + 1) % len(frames)  # Cambiar cuadro de animación
    
    # Manejar eventos
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    
    pygame.display.flip()
    pygame.time.delay(100)  # Control de velocidad de animación

pygame.quit()
