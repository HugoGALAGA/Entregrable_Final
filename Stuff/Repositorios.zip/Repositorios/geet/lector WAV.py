import struct

# Configuración del archivo de texto de entrada
input_file = "D:/Descargas/ls.txt"

# Configuración del archivo WAV de salida
output_file = "D:/Descargas/prueba/6.wav"
channels = 1
sample_rate = 8000
sample_width = 2  # bytes

# Función para crear el encabezado WAV
def create_wav_header(channels, sample_rate, sample_width, data_size):
    """Crea el encabezado WAV."""
    riff_chunk_size = data_size + 36
    fmt_chunk_size = 16
    audio_format = 1  # PCM
    byte_rate = sample_rate * channels * sample_width
    block_align = channels * sample_width
    bits_per_sample = sample_width * 8

    header = struct.pack('<4sI4s', b'RIFF', riff_chunk_size, b'WAVE')
    header += struct.pack('<4sI', b'fmt ', fmt_chunk_size)
    header += struct.pack('<hHIIHH', audio_format, channels, sample_rate, byte_rate, block_align, bits_per_sample)
    header += struct.pack('<4sI', b'data', data_size)

    return header

audio_data = []

try:
    # Lee los datos del archivo de texto
    with open(input_file, "r") as f:
        for line in f:
            try:
                # Convierte la línea a un entero
                audio_value = int(line.strip())

                # Escala el valor del ADC (0-4095) a un rango de 16 bits (-32768 a 32767)
                scaled_value = int((audio_value / 4095.0) * 65535 - 32768)

                # Convierte el valor a bytes (formato little-endian)
                data = struct.pack('<h', scaled_value)
                audio_data.append(data)

            except ValueError:
                print(f"Valor no válido en el archivo de texto: {line.strip()}, ignorando...")
                pass

except FileNotFoundError:
    print(f"Archivo de texto no encontrado: {input_file}")
    exit()

except Exception as e:
    print(f"Error al leer el archivo de texto: {e}")
    exit()

# Crea el encabezado WAV
data_size = len(audio_data) * sample_width  # Tamaño en bytes
header = create_wav_header(channels, sample_rate, sample_width, data_size)

# Escribe el archivo WAV manualmente
try:
    with open(output_file, 'wb') as wav_file:
        wav_file.write(header)
        wav_file.write(b''.join(audio_data))

    print(f"Archivo WAV creado exitosamente: {output_file}")

except Exception as e:
    print(f"Error al crear el archivo WAV: {e}")