import serial

# Configuración del puerto serial
port = "COM4"  # Reemplaza con el puerto COM de tu Arduino
baudrate = 115200
serial_port = serial.Serial(port, baudrate)

# Configuración del archivo de texto
output_file = "D:/Descargas/ls.txt"

print("Comenzando a recibir datos... Presiona Ctrl+C para detener.")

try:
    with open(output_file, "w") as f:  # Abre el archivo en modo escritura ("w")
        while True:
            try:
                # Lee una línea del puerto serial
                line = serial_port.readline().decode('utf-8').strip()

                # Intenta convertir la línea a un entero (para asegurarnos de que son datos válidos)
                data = int(line)

                # Escribe la línea en el archivo
                f.write(line + "\n")  # Agrega una nueva línea después de cada valor

                print(f"Recibido: {line}") # Muestra los datos recibidos

            except ValueError:
                print(f"Valor no válido recibido: {line}, ignorando...") # Muestra datos no válidos que se están ignorando
                pass # Ignora las líneas que no se pueden convertir a entero
            except Exception as e:
                print(f"Error inesperado: {e}") # En caso de error inesperado
                break

except KeyboardInterrupt:
    print("\nRecepción de datos finalizada.")

finally:
    serial_port.close()  # Cierra el puerto serial
    print(f"Datos guardados en: {output_file}")