#include <WiFi.h>
#include <AsyncTCP.h>
#include <ESPAsyncWebServer.h>
#include <TinyGPS++.h>

const char* ssid = "Tu_Red_WiFi";
const char* password = "Tu_Clave_WiFi";

AsyncWebServer server(80);
AsyncWebSocket ws("/ws");

TinyGPSPlus gps;
HardwareSerial neogps(1);  // UART1 para GPS
#define AUDIO_PIN 34        // Entrada ADC del micrófono

void sendData() {
    if (ws.count() > 0) {  // Si hay clientes conectados
        float lat = gps.location.lat();
        float lon = gps.location.lng();
        int audioValue = analogRead(AUDIO_PIN); // Leer ADC del micrófono

        // Crear JSON con datos
        String json = "{\"gps\": {\"lat\": " + String(lat, 6) +
                      ", \"lon\": " + String(lon, 6) +
                      "}, \"audio\": " + String(audioValue) + "}";
        ws.textAll(json); // Enviar datos a todos los clientes
    }
}

void onWebSocketEvent(AsyncWebSocket *server, AsyncWebSocketClient *client,
                      AwsEventType type, void *arg, uint8_t *data, size_t len) {
    if (type == WS_EVT_CONNECT) {
        Serial.println("Cliente WebSocket conectado.");
    }
}

void setup() {
    Serial.begin(115200);
    neogps.begin(9600, SERIAL_8N1, 16, 17); // Pines GPS RX=16, TX=17
    WiFi.begin(ssid, password);
    
    while (WiFi.status() != WL_CONNECTED) {
        delay(1000);
        Serial.println("Conectando a WiFi...");
    }

    ws.onEvent(onWebSocketEvent);
    server.addHandler(&ws);
    server.begin();
}

void loop() {
    while (neogps.available()) gps.encode(neogps.read());
    sendData();
    delay(500); // Enviar cada 500ms
}
